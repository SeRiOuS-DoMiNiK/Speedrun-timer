package net.silthus.template;

public final class Constants {

    public static final String ACF_BASE_KEY = "commands";
    public static final String INFO_CMD_PERMISSION = "stemplate.admin.info";
}
